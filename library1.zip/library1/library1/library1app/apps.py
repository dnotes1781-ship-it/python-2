from django.apps import AppConfig


class Library1AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'library1app'
