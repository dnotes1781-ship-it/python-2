from django.db import models

class Publisher(models.Model):
    publisher_name = models.CharField(max_length=100)
    contact_person = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, unique=True)
    phone_number = models.CharField(max_length=100)
    city = models.CharField(max_length=100)

    def __str__(self):
        return self.publisher_name


class Book(models.Model):
    book_title = models.CharField(max_length=100)
    isbn_number = models.CharField(max_length=100, unique=True)
    author_name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    publication_year = models.IntegerField()
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)

    def __str__(self):
        return self.book_title
