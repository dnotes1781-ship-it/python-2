from django import forms
from .models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['stud_name', 'enrol_no', 'mob_no', 'department', 'semester']
