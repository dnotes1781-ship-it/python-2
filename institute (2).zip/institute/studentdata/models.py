from django.db import models

class Department(models.Model):
    department_name = models.CharField(max_length=100)
    hod_name = models.CharField(max_length=100)
    branch = models.CharField(max_length=100)
    semester = models.IntegerField()

    def __str__(self):
        return f"{self.department_name} - {self.branch}"



class Student(models.Model):
    stud_name = models.CharField(max_length=100)
    enrol_no = models.CharField(max_length=20, unique=True)  
    mob_no = models.CharField(max_length=15)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    semester = models.IntegerField()

    def __str__(self):
        return f"{self.stud_name} ({self.enrol_no})"
