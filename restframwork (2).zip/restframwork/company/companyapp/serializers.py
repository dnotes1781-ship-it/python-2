from rest_framework import serializers
from .models import Company, Employee

class CompanySerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=100)
    location = serializers.CharField(max_length=100)
    founded_year = serializers.IntegerField()


class EmployeeSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    company = CompanySerializer()
    name = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    salary = serializers.DecimalField(max_digits=10, decimal_places=2)
    designation = serializers.CharField(max_length=100)



class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = "__all__"


class EmployeeSerializer(serializers.ModelSerializer):
    company = CompanySerializer(read_only=True)  # nested serializer

    class Meta:
        model = Employee
        fields = "__all__"
